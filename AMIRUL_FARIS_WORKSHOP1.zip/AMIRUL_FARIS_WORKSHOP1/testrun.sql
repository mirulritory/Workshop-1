-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2024 at 01:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testrun`
--

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `equipmentID` int(4) NOT NULL,
  `name` varchar(25) NOT NULL,
  `description` varchar(50) NOT NULL,
  `category` int(1) NOT NULL,
  `rentalRate` double(4,2) NOT NULL,
  `statusAvailability` varchar(1) NOT NULL,
  `maintenanceDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equipmentID`, `name`, `description`, `category`, `rentalRate`, `statusAvailability`, `maintenanceDate`) VALUES
(1, 'Badminton Net', 'Yonex', 1, 8.00, 'A', '2024-01-14'),
(2, 'Badminton Net', 'Yonex', 1, 8.00, 'N', '2024-05-06'),
(3, 'Badminton Racket', 'Yonex', 1, 10.00, 'A', '2024-04-15'),
(4, 'Badminton Racket', 'Yonex', 1, 10.00, 'A', '2024-04-25'),
(5, 'Badminton Racket', 'Victor', 1, 7.00, 'A', '2024-05-04'),
(6, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'N', '2024-02-05'),
(7, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-01-30'),
(8, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'P', '2024-02-07'),
(9, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'N', '2024-01-19'),
(10, 'Tennis Racket', 'Wilson', 3, 15.00, 'A', '2024-02-20'),
(11, 'Tennis Racket', 'Wilson', 3, 15.00, 'A', '2023-01-22'),
(13, 'Tennis Racket', 'Dunlop', 3, 15.00, 'A', '2023-01-25'),
(14, 'Badminton Racket', 'Victor', 1, 11.00, 'A', '2024-01-06'),
(15, 'Badminton Racket', 'Victor', 1, 11.00, 'A', '2024-01-20'),
(16, 'Badminton Racket', 'Victor', 1, 11.00, 'A', '2024-02-03'),
(17, 'Badminton Racket', 'Victor', 1, 11.00, 'A', '2024-02-17'),
(18, 'Badminton Racket', 'Victor', 1, 11.00, 'A', '2024-03-02'),
(19, 'Badminton Racket', 'Victor', 1, 11.00, 'A', '2024-03-16'),
(20, 'Badminton Racket', 'Victor', 1, 11.00, 'A', '2024-03-30'),
(21, 'Badminton Racket', 'Victor', 1, 11.00, 'A', '2024-04-06'),
(23, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-03-13'),
(24, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-03-17'),
(25, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-03-01'),
(26, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-04-15'),
(27, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-03-09'),
(28, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-03-12'),
(29, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-04-07'),
(30, 'Ping pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-02-15'),
(31, 'Badminton Net', 'Yonex', 1, 8.00, 'A', '2024-03-07'),
(32, 'Badminton Net', 'Yonex', 1, 8.00, 'A', '2024-02-15'),
(33, 'Badminton Net', 'Victor', 1, 7.00, 'A', '2024-01-04'),
(34, 'Badminton Net', 'Victor', 1, 7.00, 'A', '2024-03-12'),
(35, 'Badminton Net', 'Victor', 1, 7.00, 'A', '2024-01-23'),
(36, 'Badminton Net', 'Victor', 1, 7.00, 'A', '2024-02-09'),
(37, 'Tennis Racket', 'Dunlop', 3, 15.00, 'A', '2024-02-18'),
(38, 'Tennis Racket', 'Dunlop', 3, 15.00, 'A', '2024-03-13'),
(39, 'Tennis Racket', 'Wilson', 3, 15.00, 'A', '2024-03-12'),
(40, 'Tennis Racket', 'Wilson', 3, 15.00, 'A', '2024-02-05'),
(41, 'Tennis Racket', 'Prince', 3, 12.00, 'A', '2024-01-22'),
(42, 'Tennis Racket', 'Prince', 3, 12.00, 'A', '2024-02-07'),
(43, 'Tennis Racket', 'Prince', 3, 12.00, 'A', '2024-03-19'),
(44, 'Tennis Racket', 'Prince', 3, 12.00, 'D', '2024-04-12'),
(45, 'Ping Pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-03-20'),
(46, 'Ping Pong Bat', 'Butterfly', 2, 8.00, 'A', '2024-04-10'),
(47, 'Tennis Racket', 'Dunlop', 3, 15.00, 'A', '2024-03-27'),
(63, 'Tennis Racket', 'Dunlop', 3, 15.00, 'A', '2023-04-07'),
(74, 'Badminton Net', 'Yonex', 1, 8.00, 'A', '2024-02-05'),
(75, 'Badminton Net', 'Yonex', 1, 10.00, 'A', '2024-03-20'),
(76, 'Ping Pong Bat', 'Buttefly', 2, 8.00, 'D', '2024-01-22');

-- --------------------------------------------------------

--
-- Table structure for table `equipment_category`
--

CREATE TABLE `equipment_category` (
  `categoryID` int(1) NOT NULL,
  `name` varchar(25) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment_category`
--

INSERT INTO `equipment_category` (`categoryID`, `name`, `description`) VALUES
(1, 'Badminton', 'For Rental'),
(2, 'Ping Pong', 'For Rental'),
(3, 'Tennis', 'For Rental');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transactionID` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `dateTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `totalPayment` double(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transactionID`, `user`, `dateTime`, `totalPayment`) VALUES
(1, 47, '2023-10-01 00:01:17', 11.00),
(2, 40, '2023-10-01 02:08:35', 24.00),
(3, 46, '2023-10-03 05:11:25', 32.00),
(4, 43, '2023-10-10 01:13:22', 33.00),
(5, 10, '2023-10-15 18:56:10', 40.00),
(6, 8, '2023-10-17 03:30:28', 45.00),
(7, 12, '2023-10-17 13:35:02', 20.00),
(8, 6, '2023-10-23 04:39:34', 36.00),
(9, 40, '2023-10-26 08:23:44', 14.00),
(10, 5, '2023-10-27 07:25:21', 45.00),
(11, 10, '2023-11-05 01:32:26', 22.00),
(12, 43, '2023-11-11 06:35:45', 30.00),
(13, 40, '2023-11-13 01:36:23', 32.00),
(14, 3, '2023-11-15 02:06:58', 28.00),
(26, 40, '2024-11-17 15:45:50', 20.00),
(32, 44, '2024-11-23 03:38:50', 44.00),
(36, 45, '2024-11-28 09:51:10', 24.00),
(37, 43, '2024-11-28 13:58:59', 60.00),
(39, 45, '2023-11-30 06:00:39', 24.00),
(40, 44, '2023-11-30 12:43:54', 30.00),
(41, 43, '2023-12-09 02:46:08', 24.00),
(42, 40, '2023-12-10 01:42:20', 11.00),
(43, 40, '2023-12-14 02:01:16', 24.00),
(44, 44, '2023-12-14 06:46:56', 44.00),
(48, 4, '2023-12-21 10:43:44', 8.00),
(67, 3, '2023-12-26 05:32:11', 24.00),
(68, 6, '2023-12-26 02:43:33', 97.00),
(73, 46, '2023-12-29 03:11:22', 48.00),
(74, 6, '2023-12-30 05:18:09', 40.00),
(75, 47, '2023-12-29 12:18:53', 151.00),
(76, 3, '2024-01-11 08:19:58', 64.00),
(77, 4, '2024-01-12 02:00:36', 84.00),
(78, 8, '2024-01-15 10:31:01', 24.00),
(79, 9, '2024-01-16 11:21:17', 30.00),
(80, 10, '2024-01-16 23:41:38', 30.00),
(81, 11, '2024-01-18 02:35:54', 16.00),
(82, 45, '2024-01-18 11:35:47', 8.00),
(83, 46, '2024-01-18 11:36:46', 16.00),
(84, 7, '2024-01-18 11:40:04', 40.00),
(85, 8, '2024-01-18 11:40:51', 32.00),
(86, 40, '2024-01-19 02:02:22', 24.00),
(87, 40, '2024-01-22 06:38:34', 24.00),
(88, 40, '2024-01-22 19:05:06', 16.00);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_item`
--

CREATE TABLE `transaction_item` (
  `transactionID` int(4) NOT NULL,
  `equipmentID` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `subtotal` double(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_item`
--

INSERT INTO `transaction_item` (`transactionID`, `equipmentID`, `days`, `subtotal`) VALUES
(1, 15, 1, 11.00),
(2, 25, 3, 24.00),
(3, 45, 4, 32.00),
(4, 16, 3, 33.00),
(5, 27, 5, 40.00),
(6, 38, 3, 45.00),
(7, 3, 2, 20.00),
(8, 41, 3, 36.00),
(9, 5, 2, 14.00),
(10, 40, 3, 45.00),
(11, 21, 2, 22.00),
(12, 39, 2, 30.00),
(13, 26, 4, 32.00),
(14, 33, 4, 28.00),
(26, 3, 2, 20.00),
(32, 16, 4, 44.00),
(36, 8, 3, 24.00),
(37, 40, 4, 60.00),
(39, 27, 3, 24.00),
(40, 39, 2, 30.00),
(41, 41, 2, 24.00),
(42, 19, 1, 11.00),
(43, 1, 3, 24.00),
(44, 2, 3, 44.00),
(48, 7, 1, 8.00),
(67, 29, 2, 16.00),
(67, 30, 1, 8.00),
(68, 9, 2, 16.00),
(68, 35, 3, 21.00),
(68, 40, 4, 60.00),
(73, 25, 3, 24.00),
(73, 28, 3, 24.00),
(74, 23, 3, 24.00),
(74, 74, 2, 16.00),
(75, 29, 2, 16.00),
(75, 39, 5, 75.00),
(75, 41, 5, 60.00),
(76, 8, 2, 16.00),
(76, 25, 2, 16.00),
(76, 27, 2, 16.00),
(76, 28, 2, 16.00),
(77, 2, 3, 24.00),
(77, 3, 3, 30.00),
(77, 4, 3, 30.00),
(78, 6, 3, 24.00),
(79, 38, 2, 30.00),
(80, 10, 1, 15.00),
(80, 11, 1, 15.00),
(81, 45, 1, 8.00),
(81, 46, 1, 8.00),
(82, 30, 1, 8.00),
(83, 9, 2, 16.00),
(84, 7, 5, 40.00),
(85, 24, 2, 16.00),
(85, 26, 2, 16.00),
(86, 2, 3, 24.00),
(87, 6, 3, 24.00),
(88, 8, 2, 16.00);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(4) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `password` varchar(20) NOT NULL,
  `phoneNo` varchar(10) NOT NULL,
  `email` varchar(25) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `name`, `password`, `phoneNo`, `email`, `type`) VALUES
(1, 'Lim', 'lim12345 ', '0198765431', 'limJ@yahoo.com', 'Staff'),
(2, 'Razak', '1995Razak', '0134427865', 'Razak95@yahoo.com', 'Staff'),
(3, 'Mohammed', 'mohammed!789', '0123456789', 'mohammed@rocketmail.com', 'Customer'),
(4, 'Aishah', 'aishah&987', '0198765432', 'aishah@outlook.com', 'Customer'),
(5, 'Ismail', 'ismail*654', '0188776655', 'ismail@gmail.com', 'Customer'),
(6, 'Nor', 'nor@345', '0176655443', 'nor@yahoo.com', 'Customer'),
(7, 'Zainab', 'zainab^234', '0166555444', 'zainab@rocketmail.com', 'Customer'),
(8, 'Hafiz', 'hafiz%567', '0144555666', 'hafiz@outlook.com', 'Customer'),
(9, 'Farid', 'farid#789', '0133444777', 'farid@gmail.com', 'Customer'),
(10, 'Salmah', 'salmah*123', '0111222334', 'salmah@yahoo.com', 'Customer'),
(11, 'Ahmad', 'ahmad@123', '0112345678', 'ahmad@gmail.com', 'Customer'),
(12, 'Siti', 'siti#456', '0129876543', 'siti@yahoo.com', 'Customer'),
(39, 'Test', '123', '0136759576', 'test@gmail.com', 'Customer'),
(40, 'Amirul', 'amirulws1', '0136759578', 'amirulfaris40@gmail.com', 'Customer'),
(43, 'Abu', 'abu_2000', '0126016455', 'Abu24@gmail.com', 'Customer'),
(44, 'Amir', 'amir232002', '0173473212', 'Amir23@rocketmail.com', 'Customer'),
(45, 'Kamal', 'Kamal123', '0196186971', 'Kamal123@gmail.com', 'Customer'),
(46, 'Syafie', 'ssyafie!', '0111285011', 'syafie02@gmail.com', 'Customer'),
(47, 'Izham', 'izham2002', '0192194828', 'Izham2002@gmail.com', 'Customer'),
(55, 'Irfan', '1234abcd', '0111285011', 'irfansyafie@gmail.com', 'Customer'),
(56, 'Amira', '!amira!!', '0186759577', 'AmiraSERS@yahoo.com', 'Staff'),
(57, 'Rahmat', 'Rahmat1234', '0134017241', 'Rahmat@gmail.com', 'Staff'),
(58, 'Khairul', '12345678', '0126016455', 'khairul@gmail.com', 'Customer'),
(59, 'Rezza', '12345678', '0136759577', 'rezza@gmail.com', 'Staff');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equipmentID`) USING BTREE,
  ADD KEY `FK_Equipment_Category` (`category`);

--
-- Indexes for table `equipment_category`
--
ALTER TABLE `equipment_category`
  ADD PRIMARY KEY (`categoryID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transactionID`,`user`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `transaction_item`
--
ALTER TABLE `transaction_item`
  ADD PRIMARY KEY (`transactionID`,`equipmentID`),
  ADD KEY `FK_item_equipment` (`equipmentID`) USING BTREE;

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equipmentID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `equipment_category`
--
ALTER TABLE `equipment_category`
  MODIFY `categoryID` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `equipment_category`
--
ALTER TABLE `equipment_category`
  ADD CONSTRAINT `equipment_category_ibfk_1` FOREIGN KEY (`categoryID`) REFERENCES `equipment` (`equipmentID`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`userID`);

--
-- Constraints for table `transaction_item`
--
ALTER TABLE `transaction_item`
  ADD CONSTRAINT `transaction_item_ibfk_1` FOREIGN KEY (`transactionID`) REFERENCES `transaction` (`transactionID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
