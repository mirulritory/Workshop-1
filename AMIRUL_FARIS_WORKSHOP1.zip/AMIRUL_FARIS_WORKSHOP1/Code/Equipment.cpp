#include "Equipment.h"
#include "DBConnection.h"
#include <vector> 
using namespace std;


Equipment::Equipment() {
	equipmentID = 0;
	category = 0;
	name = "";
	description = "";
	statusAvailability = "";
	rentalRate = 0.0;
	maintenanceDate = "";
	days = 0;
}

Equipment::Equipment(sql::ResultSet* data) {
	equipmentID = data->getInt("equipmentID");
	name = data->getString("name");
	description = data->getString("description");
	rentalRate = data->getDouble("rentalRate");
	category = data->getInt("category");
	statusAvailability = data->getString("statusAvailability");
	maintenanceDate = data->getString("maintenanceDate");
}

vector<Equipment> Equipment::findEquipment(int category, string keyword)
{

	string query = "SELECT * FROM `equipment` WHERE "
		" (name LIKE ? OR description LIKE ?) AND category = ? ";
	
	DBConnection db;
	db.prepareStatement(query);
	db.stmt->setString(1, "%" + keyword + "%");
	db.stmt->setString(2, "%" + keyword + "%");
	db.stmt->setInt(3, category);

	vector<Equipment> equipments;

	db.QueryResult();

	if (db.res->rowsCount() > 0) {

		while (db.res->next()) {
			Equipment tmpEquipment(db.res);
			equipments.push_back(tmpEquipment);

		}
	}

	db.~DBConnection();
	return equipments;
}

Equipment Equipment::findEquipment(int equipmentID) {
	DBConnection db;
	db.prepareStatement("SELECT * FROM equipment WHERE equipmentID=?");
	db.stmt->setInt(1, equipmentID);
	db.QueryResult();

	Equipment result;
	if (db.res->rowsCount() == 1) {
		while (db.res->next()) {
			Equipment found(db.res);
			result = found;
		}
	}
	db.~DBConnection();
	return result;
}

void Equipment::updateAvailable()
{
	//updateStatus("A");
	DBConnection db;
	db.prepareStatement("UPDATE equipment SET statusAvailability = ? WHERE equipmentID = ?");
	db.stmt->setString(1, "A");
	db.stmt->setInt(2, equipmentID);
	db.QueryStatement();
	db.~DBConnection();
}

void Equipment::update()
{
	//updateStatus("N");
	DBConnection db;
	db.prepareStatement("UPDATE equipment SET statusAvailability = ? WHERE equipmentID = ?");
	db.stmt->setString(1, "N");
	db.stmt->setInt(2, equipmentID);
	db.QueryStatement();
	db.~DBConnection();
}

void Equipment::updatePending()
{
	//updateStatus("P");
	DBConnection db;
	db.prepareStatement("UPDATE equipment SET statusAvailability = ? WHERE equipmentID = ?");
	db.stmt->setString(1, "P");
	db.stmt->setInt(2, equipmentID);
	db.QueryStatement();
	db.~DBConnection();
}

void Equipment::updateDelete()
{
	//updateStatus("D");
	DBConnection db;
	db.prepareStatement("UPDATE equipment SET statusAvailability = ? WHERE equipmentID = ?");
	db.stmt->setString(1, "D");
	db.stmt->setInt(2, equipmentID);
	db.QueryStatement();
	db.~DBConnection();
}

bool Equipment::addEquipment() 
{
	DBConnection db;//instantiate
	db.prepareStatement("Insert into equipment (name,description,category,rentalRate,statusAvailability,maintenanceDate) VALUES (?,?,?,?,?,?)");
	db.stmt->setString(1, name);
	db.stmt->setString(2, description);
	db.stmt->setInt(3, category);
	db.stmt->setDouble(4, rentalRate);
	db.stmt->setString(5, statusAvailability);
	db.stmt->setString(6, maintenanceDate);
	db.QueryStatement();
	db.~DBConnection();
}

std::vector<Equipment> Equipment::getAllEquipmentData() {
	DBConnection db;

	// Assuming you have a table named 'equipment' with appropriate columns
	db.prepareStatement("SELECT * FROM equipment");
	db.QueryResult();

	std::vector<Equipment> equipmentList;

	// Process query result and populate equipmentList
	if (db.res->rowsCount() > 0) {
		while (db.res->next()) {
			Equipment equipment;
			equipment.equipmentID = db.res->getInt("equipmentID");
			equipment.name = db.res->getString("name");
			equipment.description = db.res->getString("description");
			equipment.rentalRate = db.res->getDouble("rentalRate");
			equipment.statusAvailability = db.res->getString("statusAvailability");
			equipment.maintenanceDate = db.res->getString("maintenanceDate");

			equipmentList.push_back(equipment);
		}
	}

	return equipmentList;
}



bool Equipment::search()
{
	DBConnection db;
	db.prepareStatement("SELECT * FROM equipment WHERE equipmentID=?");
	db.stmt->setInt(1, equipmentID);
	db.QueryResult();
	if (db.res->rowsCount() == 1) {
		while (db.res->next()) {
			equipmentID = db.res->getInt("equipmentID");
			name = db.res->getString("name");
			description = db.res->getString("description");
			category = db.res->getInt("category");
			rentalRate = db.res->getDouble("rentalRate");
			statusAvailability = db.res->getString("statusAvailability");
			maintenanceDate = db.res->getString("maintenanceDate");

		}
		db.~DBConnection();
		return true;
	}
	else {

		db.~DBConnection();
		return false;
	}
}

void Equipment::editEquipment()
{
	DBConnection db;
	db.prepareStatement("UPDATE equipment SET name=?, description=?, rentalRate=?, statusAvailability=?, maintenanceDate=? WHERE equipmentID=?");
	db.stmt->setString(1, name);
	db.stmt->setString(2, description);
	db.stmt->setDouble(3, rentalRate);
	db.stmt->setString(4, statusAvailability);
	db.stmt->setString(5, maintenanceDate);
	db.stmt->setInt(6, equipmentID);
	db.QueryStatement();
	//db.~DBConnection();
}

void Equipment::remove()
{
	DBConnection db;
	db.prepareStatement("DELETE FROM equipment WHERE equipmentID=?");
	db.stmt->setInt(1, equipmentID);
	db.QueryStatement();
	db.~DBConnection();
}




Equipment::~Equipment()
{

}


