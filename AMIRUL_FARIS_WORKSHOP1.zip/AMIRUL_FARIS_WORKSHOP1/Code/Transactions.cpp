#include "Transactions.h"
#include <string> 
#include <iomanip>
using namespace std;

Transaction::Transaction() {
	dateTime = "";
	transactionID = 0;
	user = 0;
	equipmentID = 0;
	days = 0;
	totalPayment = 0;
}

void Transaction::insert() {

	DBConnection db;
	try {
		// Insert the main transaction
		db.prepareStatement("INSERT INTO transaction (user, totalPayment) VALUES (?, ?)");
		db.stmt->setInt(1, user);
		db.stmt->setDouble(2, totalPayment);
		db.QueryStatement();

		// Get the generated transaction ID
		transactionID = db.getGeneratedId();

		// Insert transaction items
		db.prepareStatement("INSERT INTO transaction_item(transactionID, equipmentID, days, subtotal) VALUES (?, ?, ?, ?)");

		for (const auto& item : items) {
			db.stmt->setInt(1, transactionID);
			db.stmt->setInt(2, item.first.equipmentID);
			db.stmt->setInt(3, item.second);

			// Calculate and set the subtotal value
			double subtotal = item.first.rentalRate * item.second;
			db.stmt->setDouble(4, subtotal);

			db.QueryStatement();
		}
		db.prepareStatement("SELECT transactionID FROM transaction_item WHERE transactionID = ?");
		db.stmt->setInt(1, transactionID);
		db.QueryResult();
		std::cout << "\n\t\t        Transaction saved successfully." << std::endl;
	}
	catch (sql::SQLException& e) {
		// Handle SQL exceptions
		std::cerr << "SQL Exception: " << e.what() << " (SQL State: " << e.getSQLState() << ")" << std::endl;
	}
	catch (std::exception& e) {
		// Handle other exceptions
		std::cerr << "Exception: " << e.what() << std::endl;
	}
}

double Transaction::total() 
{
	// Implementation code
	// Replace with the actual value to return
	double total = 0;
	for (int i = 0; i < items.size(); i++) {
		total += items[i].first.rentalRate * items[i].second;
	}
	return total;
}

int Transaction::count()
{
	double count = 0;
	for (int i = 0; i < items.size(); i++) {
		count += items[i].second;
	}
	return count;
}


void Transaction::addEquipment(Equipment equipment, int days) 
{
	items.push_back({ equipment,days });
	// Implementation for the addEquipment function
	// ...
}


