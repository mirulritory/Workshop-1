#pragma once
#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>

class Account
{
public://access specifier
	int userID;
	std::string name, password, phoneNo, email, type;

	Account();// constructor method
	Account(int userID, std::string name, std::string password, std::string phoneNo, std::string email, std::string type);
	
	bool login();
	bool insert();
	bool insertStaff();
	bool updateName();
	void update();
	void remove();
	~Account();//destructor method
};
#endif
