#pragma once
#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>
#include <vector>
#include "Equipment.h"

class Transaction
{
public:

	std::string dateTime;
	int transactionID, user,equipmentID,days,totalByCat;
	double totalPayment;

	std::vector<std::pair<Equipment, int>> items; // pair of equipment and its number of days, represents the transaction_item table

	Transaction();
	void addEquipment(Equipment equipment, int days);
	void insert();
	int count() ;
	double total() ;


};


#endif

