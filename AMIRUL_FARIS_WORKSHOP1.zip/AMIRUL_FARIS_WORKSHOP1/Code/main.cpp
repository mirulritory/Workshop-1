﻿#include <iostream>
#include <conio.h>
#include <iomanip>
#include <sstream>
#include <cctype>
#include <numeric>
#include <string>
#include "Account.h"// include custom class
#include "Menu.h"
#include "Equipment.h"
#include "Transactions.h"
#include "Rent.h"
#include <mysql/jdbc.h>
#include "Validation.h"

using namespace std;

//function header
void loginMenu(); //log in menu
void registerAccount(); //registration user
void home(Account user); //user homepage
void staff(Account user); //staff homepage
//staff's functions
void registerStaff(); 
void viewTransaction(); 
void viewEquipment();
void addEquipment();
void searchMenu();
Equipment editEquipment(Equipment equip);
void staffReport();
void DisplayBarGraph(const std::vector<std::pair<std::string, double>>& data);
//user's functions
Account profile(Account user);
void rent(Account user);
Transaction equipments(Account user, int category, Transaction& cart);
Transaction equipmentDetail(Account user, int equipmentID, Transaction& cart);
Transaction cartMenu(Account user, Transaction& cart);



int main()
{
	const int numOptions = 3;
	int selectedOption = 0;

	while (true) {
		std::system("cls"); // Clear the console screen (Windows-specific)

		std::cout << "Welcome to Sports Equipment Rental System !" << endl;
		std::cout << "-------------------------------------------" << endl;

		// Display the menu options
		for (int i = 0; i < numOptions; i++) {
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options
			if (i == 0) 
			{
				std::cout << "\t\t Login" << endl;
			}
			else if (i == 1) 
			{
				std::cout << "\t\tRegister" << endl;
			}
			else if (i == 2) 
			{
				std::cout << "\t\t  Exit" << endl;
			}
		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input) {
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			// Process the selected menu option
			if (selectedOption == 0) {
				loginMenu();
			}
			else if (selectedOption == 1) {
				registerAccount();
			}
			else if (selectedOption == 2) 
			{
				std::cout << "Exiting the program" << std::endl;
				exit (0); // Exit the program
			}
			break;
			
		}
		
	}
	staffReport();
	return 0;

}

void registerAccount()
{
	const int numOptions = 6;
	int selectedOption = 0;
	Account newacc;
	bool valid = true;

	while (true) {
		std::system("cls"); // Clear the console screen (Windows-specific)

		std::cout << "------------------REGISTER-----------------" << endl;
		std::cout << "-------------------------------------------" << endl;

		// Display the menu options
		for (int i = 0; i < numOptions; i++) {
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options
			if (i == 0) {
				std::cout << "Enter Name: " << newacc.name << endl;
			}
			else if (i == 1) 
			{
				std::cout << "Enter Password: ";

				for (size_t j = 0; j < newacc.password.size(); ++j)
				{
					std::cout << '*';
				}
				std::cout << std::endl;
			}
			else if (i == 2)
			{
				std::cout << "Enter Phone Number: " << newacc.phoneNo << endl;
			}
			else if (i == 3)
			{
				std::cout << "Enter Email: " << newacc.email << endl;
			}
			else if (i == 4) 
			{
				std::cout << "Register !" << endl;
			}
			else if (i == 5) 
			{
				std::cout << "Back" << endl;
			}
		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input) {
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			// Process the selected menu option
			if (selectedOption == 0)
			{
				string name;
				std::cout << "Enter your name. . ." << endl;
				std::cin >> name;
				if (!(name.empty()) && !(name.find_first_of("0123456789") != std::string::npos))
				{
					// Capitalize the first letter of the name
					newacc.name = name;
					newacc.name[0] = std::toupper(newacc.name[0]);
					
				}
				else {
					cout << "Invalid input. The name should contain only alphabetic characters.";
					_getch();
				}
				
			}
			else if (selectedOption == 1)
			{
				std::cout << "Enter your password. . ." << endl;
				//std::cin >> newacc.password;

				int i = 0;
				while (true) 
				{
					char ch = _getch();

					if (ch == 13) 
					{  // Enter key
						newacc.password[i] = '\0';  // Null-terminate the password string
						break;
					}
					else if (ch == 8 && i > 0) 
					{  // Backspace key
						std::cout << "\b \b";
						newacc.password.pop_back();  // Remove the last character from the string
						i--;
					}
					else
					{
						newacc.password += ch;
						std::cout << '*';
						i++;
					}
				}
				if (newacc.password.length() < 8) 
				{
					std::cout << "\nPassword must be at least 8 characters. Press Enter to try again." << std::endl;
					_getch();
					newacc.password.clear(); // Clear the password and try again
					break;
				}
				
			}
			else if (selectedOption == 2)
			{
				std::cout << "Enter your phone number. . ." << endl;
				cin >> newacc.phoneNo;

				if (newacc.phoneNo.length() < 10 || newacc.phoneNo.find_first_not_of("0123456789") != std::string::npos || newacc.phoneNo.length() > 11) {
					std::cout << "\nInvalid phone number. Please enter a valid numeric phone number." << std::endl;
					_getch();
					newacc.phoneNo.clear();
					break;
				}
			}
			else if (selectedOption == 3)
			{
				std::cout << "Enter your email address. . ." << endl;
				std::cin >> newacc.email;

				while (newacc.email.find('@') == std::string::npos) {
					std::cout << "Invalid email address. Please enter a valid email\n ";
					std::cin >> newacc.email;
				}

				std::cout << "Email address: " << newacc.email << std::endl;
			}
			else if (selectedOption == 4) {
				valid = true;
				if (true)
				{
					if (newacc.insert())
					{
						std::cout << "Your account successfully registered !";
						_getch();
					}
					else
					{
					
						std::cout << "Name is already taken.";
						_getch();
						registerAccount();
						
					}
					
					_getch();
					return;
				}
			}
			else if (selectedOption == 5) {
				return;
			}
			break;

		}

	}
}

void loginMenu() 
{
	const int numOptions = 3;
	int selectedOption = 0;
	Account user;
	Equipment item;
	Menu loginMenu;


	while (true) {
		std::system("cls"); // Clear the console screen (Windows-specific)

		std::cout << "-------------------------------------------" << endl;
		std::cout << "                  LOGIN" << endl;
		std::cout << "-------------------------------------------" << endl;

		// Display the menu options
		for (int i = 0; i < numOptions; i++) {
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options
			if (i == 0) {
				std::cout << "Name: " << user.name << endl;
			}
			else if (i == 1) {
				std::cout << "Password" << endl;
				/*for (size_t j = 0; j < user.password.size(); ++j)
				{
					std::cout << '*';
				}

				std::cout << std::endl;*/
			}
			/*else if (i == 2) {
				std::cout << "\t\t  Login" << endl;
			}*/
			else if (i == 2) {
				std::cout << "\t\t  Back" << endl;
			}
		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input) {
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			// Process the selected menu option
			if (selectedOption == 0) 
			{
				string name;
				std::cout << "Enter your name. . ." << endl;
				std::cin >> name;
				if (!(name.empty()) && !(name.find_first_of("0123456789") != std::string::npos))
				{
					// Capitalize the first letter of the name
					user.name = name;
					user.name[0] = std::toupper(user.name[0]);

				}
				else {
					cout << "Invalid input. The name should contain only alphabetic characters.";
					_getch();
				}
				loginMenu.setValue(0, user.name);
			} //mirul busuk
			else if (selectedOption == 1) 
			{
				std::cout << "Enter your password. . ." << endl;
				int i = 0;
				while (true)
				{
					char ch = _getch();

					if (ch == 13) 
					{  // Enter key
						user.password[i] = '\0';  // Null-terminate the password string
						break;
					}
					else if (ch == 8 && i > 0) 
					{  // Backspace key
						std::cout << "\b \b";
						user.password.pop_back();  // Remove the last character from the string
						i--;
					}
					else 
					{
						user.password += ch;
						std::cout << '*';
						i++;
					}
					loginMenu.setValue(1, user.password);
				}
				//std::cin >> user.password;
				//loginMenu.setValue(1, user.password);
				
				std::system("cls");
				if (user.login())
				{
					if (user.type == "Customer")
					{
						home(user);
					}
					else
					{
						staff(user);
					}
				}
				else
				{
					std::cout << "Invalid Login";
					_getch();
					main();
				}
			}
			else if (selectedOption == 2) {
				return;
			}
			break;

		}

	}
}

void home(Account user) //customer interface
{
	const int numOptions = 3;
	int selectedOption = 0;
	Menu homeMenu;

	while (true) {
		std::system("cls"); // Clear the console screen (Windows-specific)

		std::cout << "    Welcome to Our Homepage " << user.name << "!!" << endl;
		std::cout << "-------------------------------------------" << endl;

		// Display the menu options
		for (int i = 0; i < numOptions; i++) {
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options
			if (i == 0) 
			{
				std::cout << "Profile" << endl;
			}
			else if (i == 1)
			{
				std::cout << "Rent Equipment" << endl;
			}
			else if (i == 2) {
				std::cout << "Logout" << endl;
			}

		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input) {
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			// Process the selected menu option
			if (selectedOption == 0)
			{
				user = profile(user);
			}
			else if (selectedOption == 1)
			{
				rent(user);
			}
			else if (selectedOption == 2) 
			{
				main();
			}
			break;

		}

	}
}

Account profile(Account user) {
	const int numOptions = 5;
	int selectedOption = 0;
	Account temp = user;
	Menu profileMenu;

	while (1)
	{
		std::system("cls"); // Clear the console screen (Windows-specific)

		profileMenu.setValue(0, temp.name);
		profileMenu.setValue(1, temp.phoneNo);
		profileMenu.setValue(2, temp.email);

		std::cout << "-------------------------------------------" << endl;

		// Display the menu options
		for (int i = 0; i < numOptions; i++)
		{
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options
			if (i == 0)
			{
				std::cout << "Name        : " << temp.name << endl;
			}
			else if (i == 1)
			{
				std::cout << "Phone Number: " << temp.phoneNo << endl;
			}
			else if (i == 2)
			{
				std::cout << "Email       : " << temp.email << endl;
			}
			else if (i == 3)
			{
				std::cout << "Delete Account" << endl;
			}
			else if (i == 4)
			{
				std::cout << "\t\t   Back" << endl;
			}

		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input)
		{
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			//cout << "-------------------------------------------" << endl;
			// Process the selected menu option
			if (selectedOption == 0)
			{
				std::cout << "Insert new name: ";
				std::cin >> temp.name;
				bool valid = true;
				if (true)
				{
					if (temp.updateName())
					{
						std::cout << "Your name is updated." << endl;
						user = temp;
						return user;
					}
					else
					{
						std::cout << "Name is already taken.";
						_getch();
						return user;
					}

				}

			}

			else if (selectedOption == 1)
			{
				//cout << "Your old password is " << temp.password << endl;
				std::cout << "Insert new phone number:";
				std::cin >> temp.phoneNo;
				user = temp;
				if (temp.phoneNo.length() < 10 || temp.phoneNo.find_first_not_of("0123456789") != std::string::npos || temp.phoneNo.length() > 11) {
					std::cout << "\nInvalid phone number. Please enter a valid numeric phone number." << std::endl;
					std::cin >> temp.phoneNo;
					//temp.phoneNo.clear();
					//break;
				}
				user = temp;
				user.update();
			}
			else if (selectedOption == 2)
			{
				std::cout << "Insert new email:";
				std::cin >> temp.email;
				while (temp.email.find('@') == std::string::npos) {
					std::cout << "Invalid email address. Please enter a valid email\n";
					std::cin >> temp.email;
				}
				user = temp;
				user.update();
			}
			else if (selectedOption == 3)
			{
				cout << "Delete your account? (y/n)";
				char confirm;
				confirm = _getch();
				if (confirm == 'Y' || confirm == 'y') {
					user = temp;
					user.remove();
					main();
				}
			}
			else if (selectedOption == 4)
			{
				return user;
			}
			break;


		}
	}
}

void staff(Account user) //staff interface
{
	const int numOptions = 7;
	int selectedOption = 0;
	
	while (true)
	{
		std::system("cls"); // Clear the console screen (Windows-specific)

		std::cout << "    Welcome to Staff Homepage " << user.name << "!!" << endl;
		std::cout << "-------------------------------------------" << endl;

		// Display the menu options
		for (int i = 0; i < numOptions; i++) {
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options
			if (i == 0)
			{
				std::cout << "Register new staff" << endl;
			}
			if (i == 1)
			{
				std::cout << "View transaction data" << endl;
			}
			if (i == 2)
			{
				std::cout << "View equipment list" << endl;
			}
			if (i == 3)
			{
				std::cout << "Add equipment" << endl;
			}
			else if (i == 4)
			{
				std::cout << "Edit Equipment" << endl;
			}
			else if (i == 5)
			{
				std::cout << "Rental Report" << endl;
			}
			else if (i == 6) 
			{
				std::cout << "Logout" << endl;
			}

		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input) {
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			// Process the selected menu option
			if (selectedOption == 0)
			{
				registerStaff();
			}
			if (selectedOption == 1)
			{
				viewTransaction();
			}
			if (selectedOption == 2)
			{
				viewEquipment();
			}
			else if (selectedOption == 3)
			{
				addEquipment();
			}
			else if (selectedOption == 4)
			{
				searchMenu();
			}
			else if (selectedOption == 5)
			{
				staffReport();
			}
			else if (selectedOption == 6)
			{
				main();
			}
			break;
		}
	}
}

void registerStaff()
{
	const int numOptions = 6;
	int selectedOption = 0;
	Account newacc;
	bool valid = true;

	while (true) {
		std::system("cls"); // Clear the console screen (Windows-specific)

		std::cout << "---------------STAFF REGISTER--------------" << endl;
		std::cout << "-------------------------------------------" << endl;

		// Display the menu options
		for (int i = 0; i < numOptions; i++) {
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options
			if (i == 0) {
				std::cout << "Enter Staff Name: " << newacc.name << endl;
			}
			else if (i == 1)
			{
				std::cout << "Enter Password: ";

				for (size_t j = 0; j < newacc.password.size(); ++j)
				{
					std::cout << '*';
				}
				std::cout << std::endl;
			}
			else if (i == 2)
			{
				std::cout << "Enter Phone Number: " << newacc.phoneNo << endl;
			}
			else if (i == 3)
			{
				std::cout << "Enter Email: " << newacc.email << endl;
			}
			else if (i == 4)
			{
				std::cout << "Register !" << endl;
			}
			else if (i == 5)
			{
				std::cout << "Back" << endl;
			}
		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input) {
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			// Process the selected menu option
			if (selectedOption == 0)
			{
				string name;
				std::cout << "Enter staff name. . ." << endl;
				std::cin >> name;
				if (!(name.empty()) && !(name.find_first_of("0123456789") != std::string::npos))
				{
					// Capitalize the first letter of the name
					newacc.name = name;
					newacc.name[0] = std::toupper(newacc.name[0]);

				}
				else {
					cout << "Invalid input. The name should contain only alphabetic characters.";
					_getch();
				}

			}
			else if (selectedOption == 1)
			{
				std::cout << "Enter staff password. . ." << endl;
				//std::cin >> newacc.password;

				int i = 0;
				while (true)
				{
					char ch = _getch();

					if (ch == 13)
					{  // Enter key
						newacc.password[i] = '\0';  // Null-terminate the password string
						break;
					}
					else if (ch == 8 && i > 0)
					{  // Backspace key
						std::cout << "\b \b";
						newacc.password.pop_back();  // Remove the last character from the string
						i--;
					}
					else
					{
						newacc.password += ch;
						std::cout << '*';
						i++;
					}
				}
				if (newacc.password.length() < 8)
				{
					std::cout << "\nPassword must be at least 8 characters. Press Enter to try again." << std::endl;
					_getch();
					newacc.password.clear(); // Clear the password and try again
					break;
				}

			}
			else if (selectedOption == 2)
			{
				std::cout << "Enter staff phone number. . ." << endl;
				cin >> newacc.phoneNo;

				if (newacc.phoneNo.length() < 10 || newacc.phoneNo.find_first_not_of("0123456789") != std::string::npos || newacc.phoneNo.length() > 11) {
					std::cout << "\nInvalid phone number. Please enter a valid numeric phone number." << std::endl;
					_getch();
					newacc.phoneNo.clear();
					break;
				}
			}
			else if (selectedOption == 3)
			{
				std::cout << "Enter staff email address. . ." << endl;
				std::cin >> newacc.email;

				while (newacc.email.find('@') == std::string::npos) {
					std::cout << "Invalid email address. Please enter a valid email\n ";
					std::cin >> newacc.email;
				}

				std::cout << "Email address: " << newacc.email << std::endl;
			}
			else if (selectedOption == 4) {
				valid = true;
				if (true)
				{
					if (newacc.insertStaff())
					{
						std::cout << "Staff account successfully registered !";
						_getch();
					}
					else
					{

						std::cout << "Name is already taken.";
						_getch();
						registerStaff();

					}

					_getch();
					return;
				}
			}
			else if (selectedOption == 5) {
				return;
			}
			break;

		}

	}
}

void viewTransaction() {
	DBConnection db;

	int transactionID;
	std::cout << "\t\t\t\tEnter the Transaction ID : ";
	std::cin >> transactionID;
	try {
		// Prepare a query to retrieve transaction details
		db.prepareStatement("SELECT t.transactionID, ti.equipmentID, ti.days, t.user AS userID, ti.subtotal, t.totalPayment, e.name "
			"FROM transaction t "
			"JOIN transaction_item ti ON t.transactionID = ti.transactionID "
			"JOIN equipment e ON ti.equipmentID = e.equipmentID "
			"WHERE t.transactionID = ?");


		// Set the parameter for the transactionID
		db.stmt->setInt(1, transactionID);

		// Execute the query
		db.QueryResult();

		// Display the header
		std::cout << "\n|" << setw(14) << "Transaction ID" << "|" << setw(20) << "Equipment ID" << "|" << setw(15) << "Equipment Name" << "|" << setw(15) << "No. of Days" << "|" << setw(15) << "User ID" << "|" << setw(15) << "Subtotal" << "|" << endl;
		std::cout << "_____________________________________________________________________________________" << endl;

		// Display the results
		while (db.res->next()) {
			int transactionID = db.res->getInt("transactionID");
			int equipmentID = db.res->getInt("equipmentID");
			int days = db.res->getInt("days");
			int userID = db.res->getInt("userID");
			double subtotal = db.res->getDouble("subtotal");
			string name = db.res->getString("name");

			std::cout << "|" << std::setw(14) << transactionID << "|" << std::setw(20) << equipmentID << "|" << std::setw(15) << name << "|" << std::setw(15) << days << "|" << std::setw(15) << userID << "|" << setw(15) << subtotal << "|" << std::endl;
		}

	}
	catch (sql::SQLException& e) {
		// Handle SQL exceptions
		std::cerr << "SQL Exception: " << e.what() << " (SQL State: " << e.getSQLState() << ")" << std::endl;
	}
	catch (std::exception& e) {
		// Handle other exceptions
		std::cerr << "Exception: " << e.what() << std::endl;
	}
	cout << "\n\t\t\t\t [Press any key to go back]" << endl;
	_getch();
}

void viewEquipment()
{
	std::vector<Equipment> equipmentList = Equipment::getAllEquipmentData();

	// Display all equipment data
	std::cout << "All Equipments:\n";
	std::cout << setw(5) << "ID" << "|" << setw(20) << "Name" << "|" << setw(15) << "Description" << "|" << setw(15) << "Rental Rate" << "|" << setw(15) << "Status Availability" << "|" << setw(20) << "Maintenance Date" << "|" << endl;
	std::cout << "____________________________________________________________________________________________________\n";
	for (const Equipment& equipment : equipmentList) {
		if (equipment.statusAvailability != "D") {
			std::cout << setw(5) << equipment.equipmentID << "|" << setw(20) << equipment.name << "|" << setw(15) << equipment.description << "|" << setw(15) << equipment.rentalRate << "|" << setw(19) << equipment.statusAvailability << "|" << setw(20) << equipment.maintenanceDate << "|" << endl;
		}

	}
	std::cout << "____________________________________________________________________________________________________\n";
	_getch();
}

void addEquipment()
{
	const int numOptions = 8;
	int selectedOption = 0;
	Equipment newequipment;
	bool valid = true;

	while (true) {
		std::system("cls"); // Clear the console screen (Windows-specific)

		std::cout << "----------------ADD EQUIPMENT--------------" << endl;
		std::cout << "-------------------------------------------" << endl;

		// Display the menu options
		for (int i = 0; i < numOptions; i++) {
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options

			if (i == 0)
			{
				std::cout << "Enter Equipment Name: " << newequipment.name << endl;
			}
			else if (i == 1)
			{
				std::cout << "Enter Description (Brand): " << newequipment.description << endl;
			}
			else if (i == 2)
			{
				std::cout << "Enter Equipment Category (1-3): " << newequipment.category << endl;
			}
			else if (i == 3)
			{
				std::cout << "Enter Rental Rate: " << newequipment.rentalRate << endl;
			}
			else if (i == 4)
			{
				std::cout << "Enter Status Availability: " << newequipment.statusAvailability << endl;
			}
			else if (i == 5)
			{
				std::cout << "Enter Maintenance Date: " << newequipment.maintenanceDate << endl;
			}
			else if (i == 6)
			{
				std::cout << "Add Equipment" << endl;
			}
			else if (i == 7)
			{
				std::cout << "Back" << endl;
			}
		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input) {
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			// Process the selected menu option
		
			if (selectedOption == 0)
			{
				string name;
				std::cout << "Enter equipment name : " << endl;
				std::getline(std::cin, name);
				if (!(name.empty()) && !(name.find_first_of("0123456789") != std::string::npos))
				{
					// Capitalize the first letter of the name
					newequipment.name = name;
					newequipment.name[0] = std::toupper(newequipment.name[0]);

				}
				else {
					cout << "Invalid input. The name should contain only alphabetic characters.";
					_getch();
				}
			}
			else if (selectedOption == 1)
			{
				string desc;
				std::cout << "Enter equipment description (Brand) : ";
				std::getline(std::cin, desc);
				if (!(desc.empty()) && !(desc.find_first_of("0123456789") != std::string::npos))
				{
					// Capitalize the first letter of the name
					newequipment.description = desc;
					newequipment.description[0] = std::toupper(newequipment.description[0]);

				}
				else {
					cout << "Invalid input. The name should contain only alphabetic characters.";
					_getch();
				}
			}
			else if (selectedOption == 2)
			{
				std::cout << "Enter equipment category : ";
				std::cin >> newequipment.category;
			}
			else if (selectedOption == 3)
			{
				std::cout << "Enter equipment rental rate : ";
				std::cin >> newequipment.rentalRate;
			}
			else if (selectedOption == 4)
			{
				std::cout << "Enter equipment status availability : ";
				std::cin >> newequipment.statusAvailability;
			}
			else if (selectedOption == 5)
			{
				std::cout << "Enter equipment maintenance date (YYYY-MM-DD) : ";
				std::cin >> newequipment.maintenanceDate;
			}
			else if (selectedOption == 6) 
			{
				cout << "Equipment added successfully." << endl;
				_getch();
				newequipment.addEquipment();
				return;
			}
			else if (selectedOption == 7) {
				return;
			}
			break;

		}

	}
}

void searchMenu()
{
	Equipment equip;
	Menu editMenu;

	std::cout << "Enter equipment ID: ";
	std::cin >> equip.equipmentID;
	editMenu.setValue(0, std::to_string(equip.equipmentID));

	if (equip.search())
	{
		equip = editEquipment(equip);
	}
	else {
		std::cout << "Invalid ID !!";
		_getch();
	}
}

Equipment editEquipment(Equipment equip)
{
	const int numOptions = 6;
	int selectedOption = 0;
	int equipmentID;
	Equipment temp = equip;
	Menu equipmentMenu;
	//std::cout << "Enter Equipment ID: ";
	//cin >> item.equipmentID;

	while (1)
	{
		std::system("cls"); // Clear the console screen (Windows-specific)

		equipmentMenu.setValue(0, temp.name);
		equipmentMenu.setValue(1, temp.description);
		//equipmentMenu.setValue(2, temp.rentalRate);
		equipmentMenu.setValue(2, temp.statusAvailability);
		equipmentMenu.setValue(4, temp.maintenanceDate);

		std::cout << "-------------------------------------------" << endl;
		//cout << "Equipment ID: " << item.equipmentID << endl;
		//equipmentMenu.setValue(3, std::to_string(temp.equipmentID));

		// Display the menu options
		for (int i = 0; i < numOptions; i++)
		{
			if (i == selectedOption) {
				std::cout << ">> ";
			}
			else {
				std::cout << "   ";
			}

			// Display the menu options
			if (i == 0)
			{
				std::cout << "Name: " << temp.name << endl;
			}
			else if (i == 1)
			{
				std::cout << "Description: " << temp.description << endl;
			}
			else if (i == 2)
			{
				std::cout << "Status: " << temp.statusAvailability << endl;
			}

			else if (i == 3)
			{
				std::cout << "Maintenance Date: " << temp.maintenanceDate << endl;
			}

			else if (i == 4)
			{
				std::cout << "Delete Equipment" << endl;
			}
			else if (i == 5)
			{
				std::cout << "Back" << endl;
			}

		}
		std::cout << "-------------------------------------------" << std::endl;
		char input = _getch(); // Read user input

		switch (input)
		{
		case 72: // Up arrow key (ASCII value)
			selectedOption = (selectedOption - 1 + numOptions) % numOptions;
			break;
		case 80: // Down arrow key (ASCII value)
			selectedOption = (selectedOption + 1) % numOptions;
			break;
		case 13: // Enter key
			std::system("cls"); // Clear the console screen

			std::cout << "-------------------------------------------" << endl;
			// Process the selected menu option
			if (selectedOption == 0)
			{
				//cout << "Your old name is " << endl;
				std::cout << "Insert new name: ";
				std::cin >> temp.name;
				equip = temp;
				equip.editEquipment();

			}

			else if (selectedOption == 1)
			{
				//cout << "Your old password is " << temp.password << endl;
				std::cout << "Insert new description: ";
				std::cin >> temp.description;
				equip = temp;
				equip.editEquipment();
			}

			else if (selectedOption == 2)
			{
				std::cout << "Insert new status: ";
				std::cin >> temp.statusAvailability;
				equip = temp;
				equip.editEquipment();
			}

			else if (selectedOption == 3)
			{
				std::cout << "Insert new maintenance date (YYYY-MM-DD): ";
				std::cin >> temp.maintenanceDate;
				equip = temp;
				equip.editEquipment();
			}

			else if (selectedOption == 4)
			{
				std::cout << "Delete the equipment? (y/n)";
				char confirm;
				confirm = _getch();
				if (confirm == 'Y' || confirm == 'y')
				{
					equip = temp;
					equip.updateDelete();
					return equip;
				}
			}

			else if (selectedOption == 5)
			{
				return equip;
			}
			break;


		}
	}
}

void rent(Account user)
{
	const int numOptions = 5;
	int selectedOption = 0;
	Transaction cart;//initialize a transaction to hold product values
	Menu rentMenu;

	cart.user = user.userID;// put currently logge in user id into the transaction

		while (1)
		{
			std::system("cls"); // Clear the console screen (Windows-specific)
			string total = to_string(cart.total());
			rentMenu.header = "Sports Equipment Rental\nTotal Price : RM" + total.erase(total.size() - 4) + "\n";




			cout << "-------------------------------------------" << endl;

			// Display the menu options
			for (int i = 0; i < numOptions; i++)
			{
				if (i == selectedOption) {
					std::cout << ">> ";
				}
				else {
					std::cout << "   ";
				}

				// Display the menu options
				if (i == 0)
				{
					std::cout << "\t        Badminton " << endl;
				}
				else if (i == 1)
				{
					std::cout << "\t        Ping Pong " << endl;
				}
				else if (i == 2)
				{
					std::cout << "\t\t Tennis" << endl;
				}
				else if (i == 3)
				{
					std::cout << "\t     View Rental Cart" << endl;
				}
				else if (i == 4)
				{
					std::cout << "\t\t  Back" << endl;
				}

			}
			std::cout << "-------------------------------------------" << std::endl;
			char input = _getch(); // Read user input

			switch (input)
			{
			case 72: // Up arrow key (ASCII value)
				selectedOption = (selectedOption - 1 + numOptions) % numOptions;
				break;
			case 80: // Down arrow key (ASCII value)
				selectedOption = (selectedOption + 1) % numOptions;
				break;
			case 13: // Enter key
				std::system("cls"); // Clear the console screen

				cout << "-------------------------------------------" << endl;
				// Process the selected menu option
				if (selectedOption == 0)
				{
					cart = equipments(user, 1, cart);

				}
				else if (selectedOption == 1)
				{
					cart = equipments(user, 2, cart);
				}
				else if (selectedOption == 2)
				{
					cart = equipments(user, 3, cart);
				}

				else if (selectedOption == 3)
				{
					cart = cartMenu(user, cart);
				}

				else if (selectedOption == 4)
				{
					home(user);
				}
				break;

			}
		}
}

Transaction equipments(Account user, int category, Transaction& cart)
{
	Equipment equip;
	vector<Equipment> equipments;
	string displayString = "";

	string keyWord = "";

	Menu equipmentMenu;
	equipmentMenu.header = "Search Option (Enter 1-3):";
	//equipmentMenu.addOption("Keyword (Search by Brand)");
	equipmentMenu.addOption("Search");
	equipmentMenu.addOption("Select");
	equipmentMenu.addOption("Back");

	

	while (1)
	{
		
		if (displayString == "") 
		{
			displayString = "\n\t\t\t\t   (STATUS)\n\t\t\t|A = Available |  P = Pending|\n\n\t\t\t\t Search Result\n--------------------------------------------------------------------------------\n";
			stringstream tmpString;
			tmpString << fixed << setprecision(2) << setw(5) << "ID" << "|" << setw(20) << "Name" << "|" << setw(20) << "Rental Rate/Day" << "|" << setw(15) << "Brand" << "|" << setw(15) << "Status" << "|" << endl;

			for (int i = 0; i < equipments.size(); i++) 
			{
				if (equipments[i].statusAvailability != "N" && equipments[i].statusAvailability != "D")
				{
					tmpString << setw(5) << equipments[i].equipmentID << "|" << setw(20) << equipments[i].name << "|" << setw(20) << equipments[i].rentalRate << "|" << setw(15) << equipments[i].description << "|" << setw(15) << equipments[i].statusAvailability << "|" << endl;
				}
			}
			displayString += tmpString.str();
			equipmentMenu.footer = "--------------------------------------------------------------------------------\n";
		}
		equipmentMenu.footer = displayString;

		switch (equipmentMenu.prompt()) {

			/// the case will modify the variable used as parameter to call the search method
		case 1:
			equipments = Equipment::findEquipment(category, keyWord);
			displayString = "";
			break;
		case 2:
			cout << "Insert Equipment Id to Select: ";

			int equipmentID;
			while (!(std::cin >> equipmentID) || !Validation::isValidNumber(std::to_string(equipmentID))) {
				std::cout << "Invalid input. Please enter a valid Equipment ID." << std::endl;

				// Clear the input buffer to allow the user to enter a new value
				std::cin.clear();
				std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

				// Prompt the user again
				cout << "Insert Equipment Id to Select: ";
			}

			cart.equipmentID = equipmentID;
			// Call the equipmentDetail function with the validated equipmentID
			cart = equipmentDetail(user, equipmentID, cart);
			break;
		case 3:
			return cart;
			break;

		}
	}

}

Transaction equipmentDetail(Account user, int equipmentID, Transaction& cart) 
{
	//Transaction result = equipmentDetail(user, equipmentID, cart);

	Equipment equipment = Equipment::findEquipment(equipmentID);
	if (equipment.equipmentID == 0 || equipment.statusAvailability != "A")
	{
		cout << "Invalid input. Try again";
		_getch();
		return cart;
	}
	//else if (equipment.equipmentID == char)

	Menu equipmentMenu;
	char confirm;
	equipmentMenu.header = "Action (Enter 1 or 2) :";
	equipmentMenu.addOption("Add to cart");
	equipmentMenu.addOption("Back");
	equipmentMenu.footer = "\n|Maximum number of days for rental is only 5 days|\n\n--------------------------------------------------\n\t\         Equipment Details\n--------------------------------------------------"
		"\nName\t\t\t: " + equipment.name
		+ "\nDescription\t\t: " + equipment.description
		+ "\nRental Rate\t\t: RM" + to_string(equipment.rentalRate);
	while (1)
	{
		switch (equipmentMenu.prompt())
		{
		case 1:
			cout << "Insert Number of Days   : ";

			// Read the input into 'days' directly
			int days;
			while (!(std::cin >> days) || !Validation::isValidNumber(std::to_string(days)) || !(days > 0 && days < 6)) {
				std::cout << "Invalid input. Please enter a valid number of days." << std::endl;

				// Clear the input buffer to allow the user to enter a new value
				std::cin.clear();
				std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

				// Prompt the user again
				cout << "Insert Number of Days   : ";
			}

			// Now, 'days' holds a valid input
			cart.days = days;
			//cart.totalByCat = totalCat;
			cart.addEquipment(equipment, cart.days);

			cout << endl << "--------------------------------------------------\n\t     Equipment Added into cart.\n\t      Press enter to continue.\n--------------------------------------------------" << endl;
			_getch();
			for (int i = 0; i < cart.items.size(); i++)
			{
				Equipment& currentItem = cart.items[i].first;
				currentItem.updatePending();  // Call the update method to change statusAvailability
			}
			return cart;
			break;
		case 2:
			return cart;
			break;
		}
	}

}

Transaction cartMenu(Account user, Transaction& cart) 
{
	
	vector<Equipment> equipments;
	Equipment item;
	Menu cartM;
	cartM.header = "Actions (Enter 1 or 2) :";
	cartM.addOption("Checkout");
	cartM.addOption("Empty Cart");
	cartM.addOption("Back");
	stringstream ss;
	ss << fixed << setprecision(2) << setw(20) << "Product|" << setw(22) << "Rental Rate|" << setw(20)
		<< "Days|" << setw(20) << "Subtotal|" << endl;
	for (int i = 0; i < cart.items.size(); i++) 
	{
		ss << setw(19) << cart.items[i].first.name << setw(22) << cart.items[i].first.rentalRate << setw(20)
			<< cart.items[i].second << setw(20) << (cart.items[i].first.rentalRate * cart.items[i].second) << endl;
	}
	ss << "----------------------------------------------------------------------------------" << endl;
	ss << setw(20) << "SUM |" << setw(20) << "" << setw(22) << setw(41) << cart.total() << "|\n----------------------------------------------------------------------------------";
	cartM.footer = "\n-----------------------------------[Cart Items]-----------------------------------\n" + ss.str();
	char confirm;
	while (1)
	{
		switch (cartM.prompt())
		{
		case 1:
			if (!cart.items.empty()) {
				cout << "\n      \t\tDo you want to check out the equipment ? (Y/N)";
				confirm = _getch();
				if (confirm == 'Y' || confirm == 'y')
				{

					cart.totalPayment = cart.total();
					cart.user = user.userID;
					cart.insert(); // insert is here
					cout << "         \t\tThank you, your receipt number : " << cart.transactionID;
					_getch();
					for (int i = 0; i < cart.items.size(); i++)
					{
						Equipment& currentItem = cart.items[i].first;
						currentItem.update();  // Call the update method to change statusAvailability
					}
					rent(user); // go back to shop with empty cart
				}
			}
			else {
				cout << "Cart is empty";
				_getch();
			}
			break;
		case 2:
			cout << "\n         \t\tAre you sure to clear your cart ? (Y/N)";
			confirm = _getch();
			if (confirm == 'Y' || confirm == 'y')
			{
				for (int i = 0; i < cart.items.size(); i++)
				{
					Equipment& currentItem = cart.items[i].first;
					currentItem.updateAvailable();  // Call the update method to change statusAvailability
				}
				rent(user); // go back to shop with empty cart
			}
			break;
		case 3:
			return cart;
		}

	}
}

void staffReport() {
	// Connect to the database
	DBConnection db;

	system("cls");

	cout << "-----------EQUIPMENT RENTAL ANALYSIS----------\n\n";

	// Get user input for month
	int month;
	bool validInput;

	do {
		std::cout << "\tEnter the month (1 - 12): ";

		// Check if the input is a valid integer
		if (!(std::cin >> month)) {
			std::cout << "Invalid input. Please enter a numeric value.\n";
			std::cin.clear();  // Clear the error flag
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Discard invalid input
			validInput = false;
		}
		else if (month < 1 || month > 12) {
			std::cout << "Invalid input. Please enter a valid month (1 - 12).\n";
			validInput = false;
		}
		else {
			validInput = true;
		}

	} while (!validInput);
	

	// Get user input for year
	int year;
	//bool validInput;

	do {
		std::cout << "\tEnter the year (yyyy)   : ";

		// Check if the input is a valid integer
		if (!(std::cin >> year)) {
			std::cout << "Invalid input. Please enter a numeric value.\n";
			std::cin.clear();  // Clear the error flag
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Discard invalid input
			validInput = false;
		}
		else if (year < 2020 || year > 2024) {
			std::cout << "Invalid input. Please enter a four-digit year.\n";
			validInput = false;
		}
		else {
			validInput = true;
		}

	} while (!validInput);

	std::cout << "\n----------------------------------------------\n";

	// Prepare a query to retrieve total payment for every month for each category
	db.prepareStatement("SELECT YEAR(t.dateTime) AS Year, "
		"MONTH(t.dateTime) AS Month, "
		"e.category AS Category, "
		"SUM(ti.subtotal) AS TotalPayment, "
		"t.dateTime AS FormattedDateTime "
		"FROM "
		"transaction t "
		"JOIN "
		"transaction_item ti ON t.transactionID = ti.transactionID "
		"JOIN "
		"user u ON t.user = u.userID "
		"JOIN "
		"equipment e ON ti.equipmentID = e.equipmentID "
		"WHERE "
		"e.category IN (1, 2, 3) "
		"AND YEAR(t.dateTime) = ? "
		"AND MONTH(t.dateTime) = ? "
		"GROUP BY "
		"YEAR(t.dateTime), MONTH(t.dateTime), e.category, t.dateTime");

	// Set the parameters
	db.stmt->setInt(1, year);  // Set the year parameter
	db.stmt->setInt(2, month); // Set the month parameter

	// Execute the query
	db.QueryResult();

	// Create a map to store the total payments for each category in the specified month
	std::map<std::pair<int, std::string>, double> categoryTotalPayments;

	while (db.res->next()) {
		int recordYear = db.res->getInt("Year");
		int recordMonth = db.res->getInt("Month");
		std::string category = db.res->getString("Category");
		double totalPayment = db.res->getDouble("TotalPayment");

		// Create a pair representing the year and category
		std::pair<int, std::string> yearCategoryPair = std::make_pair(recordYear, category);

		// Check if the record is from the specified month
		if (recordMonth == month) {
			// Check if the category is already in the map, if not, add it
			if (categoryTotalPayments.find(yearCategoryPair) == categoryTotalPayments.end()) {
				categoryTotalPayments[yearCategoryPair] = totalPayment;
			}
			else {
				// If the category is already in the map, add the total payment to its value
				categoryTotalPayments[yearCategoryPair] += totalPayment;
			}
		}
	}

	// Convert the map to a vector of pairs for the bar graph
	std::vector<std::pair<std::string, double>> categoryData;
	for (const auto& entry : categoryTotalPayments) {
		categoryData.emplace_back(entry.first.second, entry.second);
	}

	// Call the function to display the bar graph with the retrieved data
	DisplayBarGraph(categoryData);
	_getch();

	// Destructor of DBConnection will automatically close the database connection
}

// Function to display results as a bar graph
void DisplayBarGraph(const std::vector<std::pair<std::string, double>>& data) {
	// Find the maximum payment value to determine the scale
	double maxPayment = 0;
	double totalSales = 0;

	for (const auto& item : data) {
		if (item.second > maxPayment) {
			maxPayment = item.second;
		}
	}

	// Define the width of the graph
	const int graphWidth = 50;

	std::cout << "\n\n\tTotal Sales (RM) based on Category Bar Graph\n\n";
	for (const auto& item : data) {
		std::cout << std::setw(5) << "\n  " << item.first << " | ";

		int barLength = static_cast<int>((item.second / maxPayment) * graphWidth);
		int a = 219;
		for (int i = 0; i < barLength; ++i) {
			std::cout << static_cast<char>(a);
		}

		std::cout << " RM " << item.second << std::endl;
	}

	// Accumulate total sales (moved outside the loop)
	totalSales = std::accumulate(data.begin(), data.end(), 0.0,
	[](double sum, const auto& item) { return sum + item.second; });

	// Display the total sales
	std::cout << " \n\t\t     |Total : ";
	int totalBarLength = static_cast<int>((totalSales / maxPayment) * graphWidth);
	std::cout << " RM " << totalSales << "|" << std::endl;

	cout << "\n\t\t\t(INDICATOR)\n\t|1 = Badminton, 2 = Ping Pong, 3 = Tennis|\n          Press any key to back to staff menu.." << endl;

}













