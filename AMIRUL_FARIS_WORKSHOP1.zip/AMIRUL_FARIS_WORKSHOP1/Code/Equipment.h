#pragma once
#ifndef EQUIPMENT_H
#define EQUIPMENT_H

#include <string>
#include <vector>
#include "DBConnection.h"

class Equipment
{
public:
	int category, equipmentID, days;
	std::string name, description, statusAvailability, maintenanceDate;
	double rentalRate;

	Equipment();
	Equipment(sql::ResultSet* data);

	~Equipment();

	static Equipment findEquipment(int equipmentID);

	static std::vector<Equipment> findEquipment(int category, std::string keyword);

	static std::vector<Equipment> getAllEquipmentData();

	//void updateEquipment();

	void update();
	void updatePending();
	void updateAvailable();
	void updateDelete();
	bool addEquipment();
	bool search();
	void editEquipment();
	void remove();


};


#endif