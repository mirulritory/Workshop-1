#include "validation.h"
#include <cctype>

bool Validation::isValidNumber(const std::string& input) {
    // Check if each character in the input is a digit
    for (char ch : input) {
        if (!std::isdigit(ch)) {
            // Return false if any character is not a digit
            return false;
        }
    }
    // Return true if all characters are digits
    return true;
}

