#include "Account.h"
#include "DBConnection.h"
#include <vector>

using namespace std;

Account::Account() 
{
	userID = 0;
	name = "";
	password = "";
	phoneNo = "";
	email = "";
	type = "";
}
Account::Account(int userID, std::string name, std::string password, std::string phoneNo, std::string email, std::string type) 
{
	this->userID = userID;
	this->name = name;
	this->password = password;
	this->phoneNo = phoneNo;
	this->email = email;
	this->type = type;
}

bool Account::login() 
{
	
	DBConnection db;
	db.prepareStatement("SELECT * FROM user WHERE name=? AND password=?");
	db.stmt->setString(1, name);
	db.stmt->setString(2, password);
	db.QueryResult();
	if (db.res->rowsCount() == 1) {
		while (db.res->next()) {
			userID = db.res->getInt("userID");
			name = db.res->getString("name");
			password = db.res->getString("password");
			phoneNo = db.res->getString("phoneNo");
			email = db.res->getString("email");
			type = db.res->getString("type");

		}
		db.~DBConnection();
		return true;
	}
	else {

		db.~DBConnection();
		return false;
	}
}

bool Account::insert()
{
	
	DBConnection db;//instantiate 
	db.prepareStatement("SELECT name FROM user WHERE name=?");
	db.stmt->setString(1, name);
	db.QueryResult();
	
	if (db.res->rowsCount() == 1) {
		while (db.res->next()) {
			 name = db.res->getString("name"); //check in the current database row
		}
		db.~DBConnection();
		return false;

	}
	else {

		db.prepareStatement("Insert into user (name,password,phoneNo,email,type) VALUES (?,?,?,?,?)");
		db.stmt->setString(1, name);
		db.stmt->setString(2, password);
		db.stmt->setString(3, phoneNo);
		db.stmt->setString(4, email);
		db.stmt->setString(5, "Customer");
		db.QueryStatement();
		db.~DBConnection();
		return true;
	
	}
	
}

bool Account::insertStaff()
{

	DBConnection db;//instantiate 
	db.prepareStatement("SELECT name FROM user WHERE name=?");
	db.stmt->setString(1, name);
	db.QueryResult();

	if (db.res->rowsCount() == 1) {
		while (db.res->next()) {
			name = db.res->getString("name"); //check in the current database row
		}
		db.~DBConnection();
		return false;

	}
	else {

		db.prepareStatement("Insert into user (name,password,phoneNo,email,type) VALUES (?,?,?,?,?)");
		db.stmt->setString(1, name);
		db.stmt->setString(2, password);
		db.stmt->setString(3, phoneNo);
		db.stmt->setString(4, email);
		db.stmt->setString(5, "Staff");
		db.QueryStatement();
		db.~DBConnection();
		return true;

	}

}

bool Account::updateName()
{
	DBConnection db;
	db.prepareStatement("SELECT name FROM user WHERE name=?");
	db.stmt->setString(1, name);
	db.QueryResult();

	if (db.res->rowsCount() == 1) {
		while (db.res->next()) {
			name = db.res->getString("name"); //check in the current database row
		}
		db.~DBConnection();
		return false;

	}
	else {
		db.prepareStatement("UPDATE user SET name=? WHERE userID=?");
		db.stmt->setString(1, name);
		db.stmt->setInt(2, userID);
		db.QueryStatement();
		db.~DBConnection();
		return true;
	}
}

void Account::update() 
{
	DBConnection db;
	db.prepareStatement("UPDATE user SET phoneNo=?, email=? WHERE userID=?");
	//db.stmt->setString(1, name);
	db.stmt->setString(1, phoneNo);
	db.stmt->setString(2, email);
	db.stmt->setInt(3, userID);
	db.QueryStatement();
	db.~DBConnection();
}

void Account::remove() 
{
	DBConnection db;
	db.prepareStatement("DELETE FROM user WHERE userID=?");
	db.stmt->setInt(1, userID);
	db.QueryStatement();
	db.~DBConnection();
}
Account::~Account() 
{

}


